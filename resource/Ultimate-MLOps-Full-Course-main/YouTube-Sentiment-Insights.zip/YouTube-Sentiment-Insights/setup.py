from setuptools import find_packages, setup

setup(
    name = 'youtube',
    version= '0.0.0',
    author= 'Bappy',
    author_email= 'entbappy73@gmail.com',
    packages= find_packages(),
    install_requires = []

)